<?php
/**
 * 余额提现处理
**/
include("../includes/common.php");
$title='余额提现处理';
include './head.php';
if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
    <div class="col-md-12 center-block" style="float: none;">
<?php adminpermission('tixian', 1);?>
<div class="block">
<div class="block-title clearfix">
<h2>余额提现列表</h2><?php if($conf['fenzhan_daifu']>0){?><a class="btn btn-xs btn-info pull-right" href="javascript:config()">自动转账配置</a>&nbsp;<a class="btn btn-xs btn-primary pull-right" href="javascript:pl_config()">批量转账选中记录</a><?php }?>
</div>
<form method="get">
		<input type="hidden" name="my" value="search">
		<div class="input-group xs-mb-15">
			<input type="text" placeholder="请输入要搜索的提现账号或者姓名！" name="kw"
				   class="form-control text-center"
				   required>
			<span class="input-group-btn">
			<button type="button" id="search_submit" class="btn btn-primary">立即搜索</button>
			<a onclick="listTable('type=2')" style="margin-left:5px;" class="btn btn-danger hidden-xs">QQ钱包</a>
			<a onclick="listTable('type=1')" style="margin-left:5px;margin-right:5px;" class="btn btn-info hidden-xs">微信</a>
			<a onclick="listTable('type=0')" class="btn btn-warning hidden-xs">支付宝</a>
			</span>
		</div>
	</form>
<div id="listTable"></div>
    </div>
  </div>
</div>
<script src="<?php echo $cdnpublic?>layer/3.1.1/layer.js"></script>
<script src="assets/js/tixian.js?ver=<?php echo VERSION ?>"></script>
</body>
</html>